# Kubernetes v1.16以降の対応（5章）

本サンプルファイルでは、書籍内容のままだと最新のKubernetesでは動作しない箇所を適宜補足しています。
以下、その内容を記します。

## 対応のポイント

主なポイントをまとめます。1.16系でデフォルトで提供されなくなったのが次のapiです（本書に関連する部分のみ）。

* `apps/v1beta1`, `apps/v1beta2` Deployment等が影響
* `extensions/v1beta1` Ingressが影響

本書記載のマニフェストでは最初からapps/v1を指定していたため、Deployment関連のマニフェスト修正は不要です。ただ、ingress-nginx等サードパーティのアプリケーションはそうでないものがあるため、別途1.16以上のインストール方法を明示しました。

影響範囲が大きいのがIngressで

* v1.16以前: `extensions/v1beta1`
* v1.16-v1.18: `networking.k8s.io/v1beta1` に変更され、スキーマは `extensions/v1beta1` 時代と互換性あり
* v1.19以降: `networking.k8s.io/v1`が登場し、スキーマに変更あり。`networking.k8s.io/v1beta1`は引き続きサポートだが1.21系?あたりで非推奨になる予定

影響を受ける場所に関して、sampleのディレクトリはこの3系統を用意しています。

Docker Desktop, GKEともに1.19が利用可能ですが、1.19の新スキーマもまだあまり浸透しているとは言えないので、本文内（以下の読み替え参照）では`networking.k8s.io/v1beta1`を指定しています。

## 読み替え

書籍中の読み替えポイントを記載します。差分についてはdiff形式で表します。`~~~ファイル種別 〜 ~~~`のような区切りはコードブロックを示します。

### 「5.10 Ingress」のデプロイ手順（P.194）

URLを変更します。

```diff
+ Kubernetes1.16系以降を利用している場合は、次のようにデプロイします。
+ 
+ ~~~console
+ $ kubectl apply -f \
+     https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v0.46.0/deploy/static/provider/cloud/deploy.yaml
+ ~~~
```

### 「5章のコラム freshpodでイメージの更新を検知し、Podを自動更新する」のkubectlの指定（P.197）

URLを変更します。

```diff
- $ kubectl apply -f https://raw.githubusercontent.com/kubernetes/minikube/master/deploy/addons/freshpod/freshpod-rc.yaml
+ $ kubectl apply -f https://raw.githubusercontent.com/kubernetes/minikube/ec1b443722227428bd2b23967e1b48d94350a5ac/deploy/addons/freshpod/freshpod-rc.yaml
```

### 「5章のコラム  Kubernete API」のAPI名（P.200）

一部の表示がなくなります。

```diff
  ~~~console
  $ kubectl api-versions
  admissionregistration.k8s.io/v1beta1
  apiextensions.k8s.io/v1beta1
  apiregistration.k8s.io/v1
  apiregistration.k8s.io/v1beta1
  apps/v1
- apps/v1beta1
- apps/v1beta2
  authentication.k8s.io/v1
  authentication.k8s.io/v1beta1
  ...
  storage.k8s.io/v1
  storage.k8s.io/v1beta1
  v1
  ~~~
```

`extensions/v1beta1`を`networking.k8s.io/v1beta1`に読み替えてください。

```diff
- Ingressのように`extensions/v1beta1`といったAPIに属しているリソースも存在します。Kubernetesでは新しい機能のリソースはアルファ版やベータ版として取り込まれることも多く、安定版に到達するまではAPIやマニフェストファイルのスキーマにも変更が入ります。`xxx/v1beta1`、`xxx/v1beta2`といった形式のAPIが存在するのはそのためです。Kubernetesのバージョンが上がるにつれて、サポートされるAPIは増えていきます。
+ Ingressのように`networking.k8s.io/v1beta1`といったAPIに属しているリソースも存在します。Kubernetesでは新しい機能のリソースはアルファ版やベータ版として取り込まれることも多く、安定版に到達するまではAPIやマニフェストファイルのスキーマにも変更が入ります。`xxx/v1beta1`、`xxx/v1beta2`といった形式のAPIが存在するのはそのためです。Kubernetesのバージョンが上がるにつれて、サポートされるAPIは増えていきます。
```

