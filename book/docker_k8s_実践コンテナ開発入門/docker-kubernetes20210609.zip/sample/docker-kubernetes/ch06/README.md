# Kubernetes v1.16以降の対応（7章）

本サンプルファイルでは、書籍内容のままだと最新のKubernetesでは動作しない箇所を適宜補足しています。
以下、その内容を記します。

## 対応のポイント

主なポイントをまとめます。1.16系でデフォルトで提供されなくなったのが次のapiです（本書に関連する部分のみ）。

* `apps/v1beta1`, `apps/v1beta2` Deployment等が影響
* `extensions/v1beta1` Ingressが影響

本書記載のマニフェストでは最初から`apps/v1`を指定していたため、Deployment関連のマニフェスト修正は不要です。ただ、`ingress-nginx等サードパーティのアプリケーションはそうでないものがあるため、別途1.16以上のインストール方法を明示しました。

影響範囲が大きいのがIngressで

* v1.16以前: `extensions/v1beta1`
* v1.16-v1.18: `networking.k8s.io/v1beta1` に変更され、スキーマは `extensions/v1beta1` 時代と互換性あり
* v1.19以降: `networking.k8s.io/v1`が登場し、スキーマに変更あり`networking.k8s.io/v1beta1`は引き続きサポートだが1.21系?あたりで非推奨になる予定

影響を受ける場所に関して、sampleのディレクトリはこの3系統を用意しています。

Docker Desktop, GKEともに1.19が利用可能ですが、1.19の新スキーマもまだあまり浸透しているとは言えないので、本文内（以下の読み替え参照）では`networking.k8s.io/v1beta1`を指定しています。

## 本文の読み替え 

書籍中の読み替えポイントを記載します。差分についてはdiff形式で表します。`~~~ファイル種別 〜 ~~~`のような区切りはコードブロックを示します。

### 「7.3.6 独自のChartを作成する」の「Ingress」のシンプルな定義（P.258）

`extensions/v1beta1`を`networking.k8s.io/v1beta1`に読み替えてください。

```diff
  ~~~yaml
- apiVersion: extensions/v1beta1
+ apiVersion: networking.k8s.io/v1beta1
  kind: Ingress
  metadata:
    name: echo
  spec:
    rules:
    - host: ch06-echo.gihyo.local
      http:
        paths:
        - backend:
            serviceName: echo
            servicePort: 80
  ~~~
```

### 「7.3.6 独自のChartを作成する」の「Ingress」の生成されたひな形（P.258〜P.259）

`extensions/v1beta1`を`networking.k8s.io/v1beta1`に読み替えてください。

```diff
  ~~~yaml
  {{- if .Values.ingress.enabled -}}
  {{- $fullName := include "echo.fullname" . -}}
  {{- $servicePort := .Values.service.port -}}
  {{- $ingressPath := .Values.ingress.path -}}
- apiVersion: extensions/v1beta1
+ apiVersion: networking.k8s.io/v1beta1
  kind: Ingress
  metadata:
    name: {{ $fullName }}
    labels:
      app: {{ template "echo.name" . }}
      chart: {{ template "echo.chart" . }}
      release: {{ .Release.Name }}
      heritage: {{ .Release.Service }}
  {{- with .Values.ingress.annotations }}
    annotations:
  {{ toYaml . | indent 4 }}
  {{- end }}
  spec:
  {{- if .Values.ingress.tls }}
    tls:
    {{- range .Values.ingress.tls }}
      - hosts:
        {{- range .hosts }}
          - {{ . }}
        {{- end }}
        secretName: {{ .secretName }}
    {{- end }}
  {{- end }}
    rules:
    {{- range .Values.ingress.hosts }}
      - host: {{ . }}
        http:
          paths:
            - path: {{ $ingressPath }}
              backend:
                serviceName: {{ $fullName }}
                servicePort: http
    {{- end }}
  {{- end }}
  ~~~
```
