3章で利用するdocker-compose.ymlを本章でも利用します。docker-compose up -dの実行ディレクトリによって動作が変わる部分があるので、本ディレクトリで作業する場合はdocker-compose.ymlを本ディレクトリにコピーして新たにdocker-compose up -dを実行してください。

build-all.bash（bash）、build-all.ps1（powershell）はそれぞれ書籍内での動作確認に使うファイルです。
