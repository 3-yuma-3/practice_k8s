#!/bin/sh
echo "[`date`] Hello!" >> /var/log/cron.log
